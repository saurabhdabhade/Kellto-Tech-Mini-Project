package Hospo_DBMS_JDBCConnector.hdj1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBMSConnector {
	public static Connection con;
	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		con  = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root", "Black@white");
		return con;
	}

}